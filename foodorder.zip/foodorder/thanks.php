
<?php include('partials-front/menu.php'); ?>

<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Thanks</title>
<link rel="stylesheet" href="css/thanks.css">
</head>
<body>
<header>
    <h1>Thank You!</h1>
</header>
<main>
    <section>
        <p>Your order has been successfully placed. Thank you for choosing our food ordering service.</p>
    </section>
</main>
</body>
</html>

<?php include('partials-front/footer.php'); ?>
