<?php include('admin/partials/menu.php'); ?>

<h1>Update Soon...</h1>

<?php include('admin/partials/footer.php'); ?>